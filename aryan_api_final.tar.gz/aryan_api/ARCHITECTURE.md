╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║                    ARYAN FIREBASE API - VISUAL GUIDE                         ║
║                          Complete System Architecture                        ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SYSTEM ARCHITECTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

┌──────────────────────────────────────────────────────────────────────────────┐
│                          USER / TELEGRAM BOT                                 │
│                                                                              │
│   [Send APK File] → X-API-Key: aryan_abc123...                             │
└────────────────────────────┬──────────────────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                      🔥 ARYAN FIREBASE API (RENDER)                          │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Flask REST API (app.py)                                             │   │
│  │                                                                     │   │
│  │  [/extract]  ←─ Receive APK + API Key                            │   │
│  │     ├─ Validate API Key                                           │   │
│  │     ├─ Check Quota                                                │   │
│  │     └─ Process in Thread Pool                                     │   │
│  └─────────────────────────┬──────────────────────────────────────────┘   │
│                            │                                              │
│  ┌─────────────────────────┴──────────────────────────────────────────┐   │
│  │ Core Processing (core/)                                           │   │
│  │                                                                   │   │
│  │  extractor.py ────► Extract Firebase from APK                   │   │
│  │     ├─ Read APK (ZIP format)                                    │   │
│  │     ├─ Find google-services.json                               │   │
│  │     ├─ Parse XML configs                                       │   │
│  │     └─ Return JSON with all configs                            │   │
│  │                                                                   │   │
│  │  db.py ────► SQLite Database (thread-safe)                      │   │
│  │     ├─ Store API keys & quotas                                  │   │
│  │     ├─ Track scan history                                       │   │
│  │     ├─ Admin activity logs                                      │   │
│  │     └─ Increment usage counters                                 │   │
│  │                                                                   │   │
│  │  telegram.py ────► Send to Telegram Channel                      │   │
│  │     ├─ Format Firebase config message                           │   │
│  │     ├─ Send async (non-blocking)                               │   │
│  │     └─ Log to error channel if failed                          │   │
│  └─────────────────────────┬──────────────────────────────────────────┘   │
│                            │                                              │
│            ┌───────────────┴────────────────┐                             │
│            ▼                                ▼                             │
│  ┌──────────────────────┐      ┌──────────────────────┐                  │
│  │  📊 SQLite Database  │      │  📱 Telegram Channel  │                  │
│  │                      │      │                      │                  │
│  │  api_keys table      │      │  [Results Posted]    │                  │
│  │  apk_scans table     │      │  └─ Auto-formatted   │                  │
│  │  admin_log table     │      │  └─ With Firebase    │                  │
│  │  bot_stats table     │      │     config details   │                  │
│  └──────────────────────┘      └──────────────────────┘                  │
│                                                                           │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │ 🔐 ADMIN PANEL (Flask Templates)                                 │   │
│  │                                                                  │   │
│  │  /aryan/login       ─► Secure login with ID + Password         │   │
│  │  /aryan/dashboard   ─► Statistics, quotas, API key mgmt        │   │
│  │  /aryan/api/*       ─► Admin endpoints (ban, quota, etc)       │   │
│  └──────────────────────────────────────────────────────────────────┘   │
│                                                                           │
└──────────────────────────────────────────────────────────────────────────────┘
                           ▲                            ▲
                           │                            │
                           │ Query Stats               │ Send Results
                           │                            │
        ┌──────────────────┘                            └──────────────────┐
        │                                                                  │
        ▼                                                                  ▼
    [ADMIN]                                                         [TG CHANNEL]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REQUEST/RESPONSE FLOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Step 1: Bot Uploads APK
┌─────────────────────────────────────────────────────────┐
│ POST /extract                                           │
│ Headers: X-API-Key: aryan_abc123xyz789                 │
│ Body: multipart/form-data {apk: <binary_file>}         │
└─────────────────────────────────────────────────────────┘
                        ▼
Step 2: API Validates
┌─────────────────────────────────────────────────────────┐
│ ✓ API Key valid?                                       │
│ ✓ Quota available?                                     │
│ ✓ APK is valid ZIP?                                    │
└─────────────────────────────────────────────────────────┘
                        ▼
Step 3: Extract Firebase
┌─────────────────────────────────────────────────────────┐
│ Open APK (ZIP)                                          │
│ Find google-services.json or XML                       │
│ Parse & extract fields:                                │
│   - project_id                                         │
│   - api_key                                            │
│   - app_id                                             │
│   - db_url                                             │
│   - storage_bucket                                     │
│   - sender_id                                          │
└─────────────────────────────────────────────────────────┘
                        ▼
Step 4: Save & Send
┌─────────────────────────────────────────────────────────┐
│ 1. Save scan record to DB                              │
│ 2. Increment quota counter                             │
│ 3. Send results to Telegram (async)                    │
│ 4. Delete APK file immediately                         │
│ 5. Return JSON response to client                      │
└─────────────────────────────────────────────────────────┘
                        ▼
Step 5: Response
┌─────────────────────────────────────────────────────────┐
│ 200 OK                                                  │
│ {                                                       │
│   "status": "success",                                  │
│   "apk_name": "app.apk",                               │
│   "package": "com.example.app",                        │
│   "firebase": {                                         │
│     "project_id": "my-project",                        │
│     "api_key": "AIzaSy...",                            │
│     ...                                                 │
│   },                                                    │
│   "quota": {                                            │
│     "used": 1,                                          │
│     "remaining": 1999,                                  │
│     "max": 2000                                         │
│   }                                                     │
│ }                                                       │
└─────────────────────────────────────────────────────────┘


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEPLOYMENT FLOW (Render)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. LOCAL DEVELOPMENT
   ┌─────────────────────────────────────┐
   │ Git Repository (Your Computer)       │
   │                                      │
   │ app.py                              │
   │ config.py                           │
   │ requirements.txt                    │
   │ core/ db.py, extractor.py, etc      │
   │ templates/ admin login, dashboard   │
   └──────────────────┬──────────────────┘
                      │
                      │ git push
                      ▼
2. GITHUB REPOSITORY
   ┌─────────────────────────────────────┐
   │ GitHub Repo (Public or Private)      │
   │                                      │
   │ https://github.com/you/aryan-api    │
   └──────────────────┬──────────────────┘
                      │
                      │ Connect to Render
                      ▼
3. RENDER.COM DEPLOYMENT
   ┌─────────────────────────────────────┐
   │ Render Web Service (Free Tier)       │
   │                                      │
   │ ┌──────────────────────────────────┐ │
   │ │ Build Phase                      │ │
   │ │ ├─ pip install requirements.txt  │ │
   │ │ ├─ Download dependencies         │ │
   │ │ └─ Ready to start                │ │
   │ └──────────────┬───────────────────┘ │
   │               │                       │
   │ ┌─────────────▼───────────────────┐  │
   │ │ Start Phase                     │  │
   │ │ ├─ python app.py                │  │
   │ │ ├─ Flask runs on port 5000      │  │
   │ │ ├─ Auto-HTTPS enabled           │  │
   │ │ └─ Ready for requests            │  │
   │ └──────────────┬────────────────────┘ │
   │               │                        │
   │ ┌─────────────▼────────────────────┐  │
   │ │ Running Service                  │  │
   │ │ ├─ SQLite: /tmp/aryan.db        │  │
   │ │ ├─ Storage: /tmp/aryan_uploads  │  │
   │ │ ├─ Logs: Real-time in dashboard │  │
   │ │ └─ Custom domain ready          │  │
   │ └─────────────────────────────────┘  │
   │                                       │
   │ Environment Variables:                │
   │ ├─ TG_BOT_TOKEN                     │
   │ ├─ TG_CHANNEL_ID                    │
   │ ├─ PORT (auto: 5000)               │
   │ └─ DATABASE_URL                     │
   └─────────────────────────────────────┘
                      │
                      │ LIVE!
                      ▼
4. PRODUCTION ACCESS
   ┌─────────────────────────────────────┐
   │ https://aryan-api.onrender.com      │
   │                                      │
   │ API:    /extract, /status, /health  │
   │ Admin:  /aryan                      │
   │ Status: ✅ Online & Running         │
   └─────────────────────────────────────┘


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DATA FLOW: APK TO TELEGRAM RESULT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Bot/User
   │
   │ 📤 Uploads myapp.apk (50MB)
   ▼
/tmp/uploads/20260612_143045_myapp.apk
   │
   ├─ ✓ Validation (ZIP format?)
   │
   ├─ ✓ Extraction (aapt dump badging)
   │
   ├─ 🔍 Parse google-services.json
   │   ├─ project_id: my-firebase-project
   │   ├─ api_key: AIzaSy...
   │   ├─ db_url: https://my-project.firebaseio.com
   │   └─ storage_bucket: my-project.appspot.com
   │
   ├─ 💾 Save to Database
   │   └─ INSERT INTO apk_scans (...)
   │
   ├─ 📱 Send to Telegram (async)
   │   │
   │   └─► @Aryan_babu99 Firebase Configuration
   │       APK: myapp.apk
   │       Package: com.example.app
   │       
   │       🔥 Firebase Config:
   │       Project ID: my-firebase-project
   │       API Key: AIzaSy...
   │       DB URL: https://my-project...
   │       Storage: my-project.appspot.com
   │       
   │       Time: 2.45s
   │
   ├─ 🗑️ Delete APK
   │   └─ rm /tmp/uploads/...
   │
   └─ 📤 Return JSON Response
      {
        "status": "success",
        "firebase": {...},
        "quota": {"remaining": 1999}
      }


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ADMIN PANEL WORKFLOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Admin
  │
  ├─► https://aryan-api.onrender.com/aryan
  │   │
  │   └─► Login Screen
  │       ID: 7949539794
  │       Password: ••••••••
  │       [🔓 Unlock]
  │
  ├─► Authenticated ✓
  │
  ├─► Dashboard
  │   ├─ 📊 Statistics
  │   │  ├─ Total Scans: 245
  │   │  ├─ Today: 12
  │   │  ├─ Active Keys: 5
  │   │  └─ Connected Bots: 3
  │   │
  │   ├─ 🔑 API Keys
  │   │  ├─ [aryan_abc123xyz...] | Used: 120/2000 | ✓ Active
  │   │  ├─ [aryan_def456uvw...] | Used: 0/1000   | ✗ Banned
  │   │  └─ [aryan_ghi789...] | Used: 98/2000   | ✓ Active
  │   │
  │   └─ 📋 Activity Log
  │      ├─ 2026-06-12 14:30 SET_QUOTA key: abc123, limit: 2000
  │      ├─ 2026-06-12 14:20 BAN_KEY key: def456
  │      └─ 2026-06-12 14:10 SET_QUOTA key: ghi789, limit: 1500
  │
  └─► Actions
     ├─ Edit Quotas
     │  └─ Select key → New limit → Save
     │
     ├─ Ban/Unban Keys
     │  └─ Select key → Ban → Confirm
     │
     └─ View Scan History
        └─ See all processed APKs


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
API SECURITY MODEL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Client Request
   │
   ├─ Step 1: API Key Validation
   │  │
   │  └─► Header: X-API-Key: aryan_abc123xyz...
   │      │
   │      └─► Check in database
   │          ├─ Key exists?
   │          ├─ Not banned?
   │          └─ Active = 1?
   │
   ├─ Step 2: Quota Check
   │  │
   │  └─► Query: SELECT quota_used, quota_max FROM api_keys
   │      ├─ remaining = max - used
   │      └─ if remaining > 0 → Allow
   │          else → Reject with 429
   │
   ├─ Step 3: Request Processing
   │  │
   │  └─► Lock: Thread-safe database access
   │      ├─ Process APK
   │      ├─ Increment counter
   │      └─ Log action
   │
   └─ Step 4: Response
      │
      ├─ 200 OK + Full Firebase config
      ├─ OR 429 Quota Exceeded
      ├─ OR 401 Invalid Key
      ├─ OR 403 Banned Key
      └─ OR 500 Processing Error


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FILE CLEANUP PROCESS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

APK Upload
   │
   ▼
Saved to /tmp/uploads/timestamp_filename.apk
   │
   ├─ Processing Starts (in separate thread)
   │
   ├─ Extraction Completes
   │
   ├─ Results Sent to Telegram
   │
   ├─ Database Updated
   │
   ├─ Delete Thread Spawned
   │  │
   │  └─ Wait 2 seconds (APK_CLEANUP_DELAY)
   │     │
   │     └─ Check: File exists?
   │        │
   │        ├─ Yes → os.remove(filepath) ✓
   │        └─ No  → Skip (already deleted)
   │
   ▼
File Completely Gone ✓


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONCURRENT PROCESSING CAPACITY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ThreadPool: 100 Workers Max

Scenario: 100 APKs uploaded simultaneously

Bot1 sends apk1.apk → Thread 1 processes
Bot2 sends apk2.apk → Thread 2 processes
Bot3 sends apk3.apk → Thread 3 processes
...
Bot100 sends apk100.apk → Thread 100 processes

All running in parallel:
├─ Database queries locked (no conflicts)
├─ File I/O parallelized
├─ Network requests (Telegram) async
└─ Results sent as completed

Performance:
├─ Processing time: ~2-5 seconds per APK
├─ With 100 workers: All 100 done in ~5 seconds
├─ Memory: Constant (streaming file I/O)
└─ CPU: Full utilization (good!)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DATABASE SCHEMA (Visual)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

api_keys TABLE
┌─────────────────────────────────────────────────────┐
│ id  │ api_key           │ quota_used │ quota_max     │
├─────┼───────────────────┼────────────┼───────────────┤
│ 1   │ aryan_abc123...   │ 45         │ 2000          │
│ 2   │ aryan_def456...   │ 0          │ 1000          │
│ 3   │ aryan_ghi789...   │ 98         │ 2000          │
└─────────────────────────────────────────────────────┘
        ▲ Primary Key    ▲ Unique       ▲ Track Usage

apk_scans TABLE
┌─────────────────────────────────────────────────────────┐
│ id  │ apk_name   │ package         │ firebase_config     │
├─────┼────────────┼─────────────────┼─────────────────────┤
│ 1   │ app1.apk   │ com.ex.app1     │ {...JSON...}        │
│ 2   │ app2.apk   │ com.ex.app2     │ {...JSON...}        │
│ 3   │ app3.apk   │ com.ex.app3     │ {...JSON...}        │
└─────────────────────────────────────────────────────────┘
        ▲ History       ▲ Package       ▲ Extracted Data

admin_log TABLE
┌──────────────────────────────────────────────────────┐
│ admin_id │ action    │ details               │ time  │
├──────────┼───────────┼───────────────────────┼───────┤
│ 7949...  │ SET_QUOTA │ key: abc, limit: 2000 │ 14:30 │
│ 7949...  │ BAN_KEY   │ key: def              │ 14:20 │
│ 7949...  │ UNBAN_KEY │ key: ghi              │ 14:10 │
└──────────┴───────────┴───────────────────────┴───────┘
        ▲ Who Did It   ▲ What Changed   ▲ When


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RENDER INFRASTRUCTURE (Free Tier)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your Code ─────┐
               │ Git Push
               ▼
         GitHub Repo
               │
               ▼ Auto-Deploy
         ┌─────────────────────────────────────┐
         │ Render Data Center (Oregon/EU)      │
         │                                     │
         │ ┌──────────────────────────────┐   │
         │ │ Linux Container              │   │
         │ │ - Python 3.11                │   │
         │ │ - 512MB RAM (Free)           │   │
         │ │ - Shared CPU                 │   │
         │ │ - 100GB bandwidth/month      │   │
         │ └──────────────────────────────┘   │
         │                                     │
         │ ┌──────────────────────────────┐   │
         │ │ Storage (Ephemeral)          │   │
         │ │ - /tmp/ - Auto-cleared 24h   │   │
         │ │ - /home/ - Persistent build  │   │
         │ └──────────────────────────────┘   │
         │                                     │
         │ ┌──────────────────────────────┐   │
         │ │ Network                      │   │
         │ │ - Automatic HTTPS/SSL        │   │
         │ │ - Custom domain support      │   │
         │ │ - DDoS protection            │   │
         │ └──────────────────────────────┘   │
         │                                     │
         │ ┌──────────────────────────────┐   │
         │ │ Built-in Services            │   │
         │ │ - PostgreSQL (paid)          │   │
         │ │ - Redis (paid)               │   │
         │ │ - Cron jobs                  │   │
         │ └──────────────────────────────┘   │
         └─────────────────────────────────────┘
               │
               │ https://aryan-api.onrender.com
               ▼
           Live & Running!


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This complete system provides:
✅ REST API for APK processing
✅ Automatic result distribution (Telegram)
✅ Admin control panel
✅ Quota management
✅ Concurrent processing (100+ simultaneous)
✅ Zero-cost hosting (Render free tier)
✅ Production-ready code
✅ Security best practices

Ready to deploy! 🚀

