# 🔥 ARYAN FIREBASE EXTRACTOR API

**Production-ready Firebase config extraction from APK files — optimized for Render hosting**

> Extract Firebase configurations from Android APK files via REST API. Perfect for company internal tools and security auditing.

---

## ✨ Features

✅ **APK Firebase Extraction** — Extract all Firebase configurations from APK files
✅ **REST API** — Simple JSON responses, easy integration  
✅ **Quota System** — Per-API-key quota limits (default 2000 APKs)
✅ **Admin Panel** — Manage API keys, quotas, and view statistics  
✅ **Telegram Integration** — Auto-send results to your company channel  
✅ **Instant Deletion** — APK files deleted immediately after processing  
✅ **Thread-Safe DB** — Concurrent processing (100+ APKs simultaneously)  
✅ **Render Ready** — One-click deployment, no server setup needed  

---

## 🚀 Quick Start (Render)

### 1. Fork/Download This Repo
```bash
git clone https://github.com/your-username/aryan-firebase-api.git
cd aryan_api
```

### 2. Deploy to Render
1. Go to [render.com](https://render.com)
2. Connect GitHub account
3. Click "New Web Service"
4. Select this repository
5. Build: `pip install -r requirements.txt`
6. Start: `python app.py`
7. Add env variables:
   - `TG_BOT_TOKEN` = your Telegram bot token
   - `TG_CHANNEL_ID` = -1003694677261
8. Deploy! ✨

### 3. Admin Panel
- **URL:** https://your-service.onrender.com/aryan
- **ID:** 7949539794
- **Password:** Vishal12

---

## 📡 API Usage

### Upload APK
```bash
curl -X POST \
  -H "X-API-Key: aryan_abc123..." \
  -F "apk=@myapp.apk" \
  https://your-service.onrender.com/extract
```

### Response
```json
{
  "status": "success",
  "apk_name": "myapp.apk",
  "package": "com.example.app",
  "firebase": {
    "project_id": "my-firebase-project",
    "api_key": "AIzaSy...",
    "app_id": "1:123456:android:abc...",
    "db_url": "https://my-project.firebaseio.com",
    "storage_bucket": "my-project.appspot.com",
    "sender_id": "123456789"
  },
  "uploaded_by": "@Aryan_babu99",
  "timestamp": "2026-06-12T14:30:45",
  "processing_time_seconds": 2.45,
  "quota": {
    "used": 1,
    "remaining": 1999,
    "max": 2000
  }
}
```

### Check Status
```bash
curl -H "X-API-Key: aryan_..." \
  https://your-service.onrender.com/status
```

---

## 🔧 Local Development

### Setup
```bash
# Python 3.9+
python3 -m venv venv
source venv/bin/activate

# Dependencies
pip install -r requirements.txt

# AAPT (Ubuntu/Debian)
sudo apt-get install aapt

# Environment
cp .env.example .env
# Edit .env with your credentials
```

### Run
```bash
python app.py
```

- API: http://localhost:5000
- Admin: http://localhost:5000/aryan
- Docs: http://localhost:5000

---

## 🔐 Security

| Feature | Details |
|---------|---------|
| **API Keys** | Unique per user/bot, can be banned/revoked |
| **Admin Auth** | Session-based, encrypted cookies |
| **Quotas** | Per-key rate limiting |
| **File Cleanup** | APKs deleted instantly after processing |
| **Activity Log** | All admin actions tracked |

---

## 📊 Admin Panel

**Dashboard shows:**
- 📈 Total scans, today's scans
- 🔑 Active API keys
- 🤖 Connected bots
- 📋 Activity logs
- ⚙️ Quota controls

**Manage API keys:**
- Ban/unban keys
- Adjust quotas
- View usage history

---

## 🔗 Telegram Integration

### Setup
1. Create bot with @BotFather
2. Copy token to config
3. Add bot as admin to channel/group
4. Get Chat ID from @userinfobot
5. Set TG_CHANNEL_ID in config

Results auto-sent to channel after each extraction!

---

## 📁 File Structure

```
aryan_api/
├── app.py                    ← Main Flask app
├── config.py                 ← Configuration
├── requirements.txt          ← Dependencies
├── render.yaml              ← Render config
├── SETUP_GUIDE.md           ← Detailed guide
├── example_bot.py           ← Bot example
├── core/
│   ├── db.py               ← Database (SQLite)
│   ├── extractor.py        ← APK extraction
│   └── telegram.py         ← TG integration
└── templates/
    ├── admin_login.html    ← Login page
    └── admin_dashboard.html ← Dashboard
```

---

## ⚙️ Configuration

Edit `config.py`:

```python
# Admin
ADMIN_ID = "7949539794"
ADMIN_PASSWORD = "Vishal12"
SECRET_KEY = "Ctrl"

# Telegram
TG_BOT_TOKEN = "..."
TG_CHANNEL_ID = "-1003694677261"

# Quotas
MAX_APK_QUOTA = 2000
MAX_CONCURRENT_PROCESSING = 100
APK_CLEANUP_DELAY = 2  # seconds
```

---

## 🚨 Limits

| Limit | Value |
|-------|-------|
| Max APK size | 100 MB |
| Max quota per key | 2000 |
| Concurrent processing | 100 APKs |
| Processing timeout | 60 seconds |
| Storage type | Ephemeral (/tmp) |

---

## 🐛 Troubleshooting

**APK not processing?**
- Verify APK is valid (ZIP format)
- Check AAPT installed: `apt-get install aapt`
- View Render logs for details

**Firebase config empty?**
- Some apps don't have exposed configs
- Obfuscated apps return partial data
- Check "auth_required" flag

**Out of quota?**
- Admin panel → API key → increase limit
- Or contact admin

---

## 📦 Deployment Options

### Render (Recommended - Free)
See SETUP_GUIDE.md → Deployment section

### Heroku
```bash
heroku create your-app
git push heroku main
```

### VPS/RDP (Any Linux)
```bash
python app.py  # or use gunicorn/nginx
```

---

## 📚 Example Bot

See `example_bot.py` for a complete Telegram bot that:
- Accepts APK uploads
- Calls this API
- Shows progress
- Returns results with formatting

---

## 🤝 Contributing

Issues/PRs welcome!

---

## 📄 License

Personal use only — company internal tool.

---

## 👨‍💻 Support

- 📖 See `SETUP_GUIDE.md` for detailed docs
- 🔍 Check logs in Render dashboard
- 💬 Review `example_bot.py` for API usage

---

**Status:** Production Ready ✅  
**Version:** 1.0  
**Last Updated:** June 2026

---

Made with ❤️ for internal use
