╔══════════════════════════════════════════════════════════════════════════╗
║              ARYAN FIREBASE API - SETUP & DEPLOYMENT GUIDE              ║
║                    Render-Optimized | Production-Ready                  ║
╚══════════════════════════════════════════════════════════════════════════╝

## 📋 PROJECT STRUCTURE

aryan_api/
├── app.py                 ← Main Flask application
├── config.py              ← Configuration (credentials, limits, etc)
├── requirements.txt       ← Python dependencies
├── render.yaml           ← Render deployment config
├── .env.example          ← Environment variables template
├── core/
│   ├── db.py            ← SQLite database layer (thread-safe)
│   ├── extractor.py     ← Firebase extraction logic
│   └── telegram.py      ← Telegram integration
└── templates/
    ├── admin_login.html  ← Admin panel login screen
    └── admin_dashboard.html ← Admin statistics & controls

---

## 🚀 DEPLOYMENT ON RENDER.COM

### Step 1: Prepare Your Code

```bash
cd aryan_api
git init
git add .
git commit -m "Initial commit"
```

### Step 2: Create Render Account
- Go to https://render.com
- Sign up (free)
- Connect GitHub account

### Step 3: Deploy
1. Click "New" → "Web Service"
2. Connect your GitHub repository
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `gunicorn app:app`
5. Add environment variables:
   - TG_BOT_TOKEN = [Your bot token]
   - TG_CHANNEL_ID = -1003694677261
6. Click "Deploy"

---

## 🔧 LOCAL TESTING

### Setup
```bash
# Install Python 3.9+
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install AAPT (required for APK extraction)
# Ubuntu/Debian:
sudo apt-get install aapt

# Copy env template
cp .env.example .env
# Edit .env with your credentials
```

### Run Locally
```bash
python app.py
```

Access:
- API: http://localhost:5000
- Admin: http://localhost:5000/aryan
  - ID: 7949539794
  - Password: Vishal12

---

## 📱 TELEGRAM BOT SETUP

### 1. Create Bot
```
Chat with @BotFather on Telegram
/newbot
Follow prompts
Copy the bot token
```

### 2. Get Channel/Group ID
```
1. Add your bot as admin to your channel/group
2. Forward any message from channel to @userinfobot
3. Copy the Chat ID (e.g., -1003694677261)
```

### 3. Set in Config
```python
# config.py
TG_BOT_TOKEN = "YOUR_BOT_TOKEN"
TG_CHANNEL_ID = "-1003694677261"
```

---

## 🔑 API USAGE

### 1. Create API Key (Admin Panel)
- Go to /aryan
- Login with credentials
- Create new API key for each bot/user

### 2. Upload & Extract APK

```bash
curl -X POST \
  -H "X-API-Key: aryan_abc123def456..." \
  -F "apk=@myapp.apk" \
  https://your-render-url/extract
```

### Response (JSON)
```json
{
  "status": "success",
  "apk_name": "myapp.apk",
  "package": "com.company.app",
  "firebase": {
    "project_id": "my-project-id",
    "api_key": "AIzaSy...",
    "app_id": "1:123456:android:abcdef...",
    "db_url": "https://my-project.firebaseio.com",
    "storage_bucket": "my-project.appspot.com",
    "sender_id": "123456789"
  },
  "uploaded_by": "@Aryan_babu99",
  "timestamp": "2026-06-12T14:30:45.123456",
  "processing_time_seconds": 2.45,
  "quota": {
    "used": 1,
    "remaining": 1999,
    "max": 2000
  }
}
```

### 3. Check Quota

```bash
curl -H "X-API-Key: aryan_..." \
  https://your-render-url/status
```

---

## 🔐 ADMIN PANEL FEATURES

Access: https://your-render-url/aryan

**Security:**
- Login: User ID `7949539794` + Password `Vishal12`
- Session-based authentication
- Server-side validation

**Features:**
- 📊 Real-time statistics (total scans, today's scans, active keys, connected bots)
- 🔑 API key management (view, create, ban/unban)
- 📈 Quota controls (increase/decrease per key)
- 📋 Activity logs (all admin actions tracked)
- 👁️ Scan history (recent extractions)

**Quota Management:**
- Default: 2000 APKs per key
- Admin can adjust per key
- Automatic tracking
- Real-time remaining quota

---

## 🛡️ SECURITY FEATURES

1. **API Key Authentication**
   - Header: `X-API-Key: aryan_...`
   - Query param: `?api_key=aryan_...`
   - Banned keys automatically rejected

2. **Admin Panel**
   - Strong password protection
   - Session encryption
   - IP logging (optional)
   - Activity tracking

3. **Rate Limiting**
   - Per-key quota system
   - Max 100 concurrent APK processing
   - Automatic quota increment

4. **File Security**
   - APK instant deletion after processing
   - Ephemeral storage on Render
   - No logs stored

---

## ⚙️ PERFORMANCE & OPTIMIZATION

### Concurrency
- Thread pool: 100 workers max
- Processing happens in background
- Results sent asynchronously to Telegram

### Storage (Render)
- Ephemeral filesystem: `/tmp/`
- Files auto-deleted after 2 seconds
- Database: SQLite (can upgrade to PostgreSQL)

### Scalability
- Render free tier: ~20 requests/sec
- Pro tier: 100+ requests/sec
- Add PostgreSQL for production

---

## 📊 MONITORING & LOGS

### View Logs (Render Dashboard)
1. Go to your service
2. Logs tab
3. Real-time stream

### Local Logs
```bash
tail -f aryan_firebase.log
```

---

## 🔄 BOT INTEGRATION

Your Telegram bot can call this API:

```python
import requests

api_key = "aryan_abc123..."
api_url = "https://your-render-url"

# Upload APK
with open("app.apk", "rb") as f:
    files = {'apk': f}
    headers = {'X-API-Key': api_key}
    
    response = requests.post(
        f"{api_url}/extract",
        files=files,
        headers=headers
    )

result = response.json()
print(result)
```

---

## 🐛 TROUBLESHOOTING

### APK Not Processing
- Check file is valid APK (ZIP format)
- Verify AAPT installed (`apt-get install aapt`)
- Check Render logs

### Firebase Config Not Extracted
- Check APK contains Google Play Services
- Some apps use obfuscation — will return empty fields
- Check "auth_required" flag in response

### Telegram Not Sending
- Verify bot token is correct
- Check bot is in channel/group as admin
- Check TG_CHANNEL_ID is correct

### Out of Quota
- Contact admin to increase limit
- Admin panel: /aryan → Select API key → Edit quota

---

## 📝 PRODUCTION CHECKLIST

- [ ] Change admin credentials in config.py
- [ ] Set strong SECRET_KEY
- [ ] Configure PostgreSQL (not SQLite for production)
- [ ] Set DEBUG = False
- [ ] Add error monitoring (Sentry, etc)
- [ ] Setup automated backups
- [ ] Configure CORS if needed
- [ ] Add rate limiting per IP
- [ ] SSL certificate (Render handles this)
- [ ] Regular security audits

---

## 🤝 SUPPORT

For issues:
1. Check logs: Render dashboard → Logs tab
2. Test locally first
3. Verify credentials and tokens
4. Check GitHub for updates

---

Generated: 2026-06-12
Version: 1.0
Status: Production Ready ✅
