#!/usr/bin/env python3
"""
╔══════════════════════════════════════════╗
║     ARYAN FIREBASE API - MAIN APP        ║
║      Render-Optimized | Async Ready      ║
╚══════════════════════════════════════════╝
"""

from flask import Flask, request, jsonify, render_template, session, redirect, url_for
from functools import wraps
import os
import json
import asyncio
import hashlib
from datetime import datetime, timedelta
from werkzeug.utils import secure_filename
import threading
from concurrent.futures import ThreadPoolExecutor

# Import our modules
from config import *
from core.db import init_db, get_db
from core.extractor import extract_firebase
from core.telegram import init_telegram, send_scan_result
import logging

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🚀 INITIALIZATION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database
db = init_db()
tg_bot = init_telegram()

# Thread pool for heavy processing
executor = ThreadPoolExecutor(max_workers=MAX_CONCURRENT_PROCESSING)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🔐 AUTHENTICATION
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def admin_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_logged_in' not in session:
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

def api_key_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key') or request.args.get('api_key')
        
        if not api_key:
            return jsonify({'error': 'Missing API key', 'status': 'error'}), 401
        
        key_info = db.get_api_key_info(api_key)
        if not key_info or not key_info.get('active'):
            return jsonify({'error': 'Invalid or banned API key', 'status': 'error'}), 403
        
        request.api_key = api_key
        request.api_key_info = key_info
        return f(*args, **kwargs)
    return decorated_function

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🏠 PUBLIC ROUTES
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.route('/')
def index():
    return jsonify({
        'status': 'ok',
        'service': 'Aryan Firebase Extractor API',
        'version': '1.0',
        'endpoints': {
            'POST /extract': 'Upload APK and extract Firebase config',
            'GET /status': 'Check quota status',
            'GET /aryan': 'Admin panel (login required)',
        }
    }), 200

@app.route('/health')
def health():
    """Health check for Render"""
    return jsonify({'status': 'healthy'}), 200

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  📱 API ENDPOINTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.route('/extract', methods=['POST'])
@api_key_required
def extract_apk():
    """
    Upload APK → Extract Firebase → Send to Telegram → Delete APK
    
    curl -X POST -H "X-API-Key: aryan_xxx" \
         -F "apk=@app.apk" \
         https://api-domain/extract
    """
    
    # Check quota
    used, remaining, can_process = db.check_quota(request.api_key)
    if not can_process:
        return jsonify({
            'status': 'error',
            'error': 'Quota exceeded',
            'quota': {'used': used, 'remaining': 0, 'max': request.api_key_info['quota_max']}
        }), 429
    
    # Check file
    if 'apk' not in request.files:
        return jsonify({'status': 'error', 'error': 'No APK file provided'}), 400
    
    file = request.files['apk']
    if file.filename == '':
        return jsonify({'status': 'error', 'error': 'No file selected'}), 400
    
    if not file.filename.lower().endswith('.apk'):
        return jsonify({'status': 'error', 'error': 'File must be .apk format'}), 400
    
    # Save APK
    filename = secure_filename(file.filename)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filepath = os.path.join(UPLOAD_FOLDER, f"{timestamp}_{filename}")
    
    try:
        file.save(filepath)
        
        # Extract Firebase (sync call, fast enough)
        start_time = datetime.now()
        result, error, processing_time = extract_firebase(filepath)
        
        if error:
            logger.error(f"Extraction error: {error}")
            
            # Send error to Telegram
            asyncio.run(tg_bot.send_error_log(error, filename))
            
            # Delete APK immediately
            try:
                os.remove(filepath)
            except:
                pass
            
            return jsonify({
                'status': 'error',
                'error': error,
                'timestamp': datetime.now().isoformat()
            }), 500
        
        # Increment quota
        db.increment_quota(request.api_key)
        used, remaining, _ = db.check_quota(request.api_key)
        
        # Record in database
        firebase_config = result.get('firebase', {})
        package_name = result.get('package', 'unknown')
        db.record_scan(request.api_key, filename, package_name, firebase_config, processing_time)
        
        # Send to Telegram (async, don't wait)
        threading.Thread(
            target=lambda: asyncio.run(send_scan_result(result, filename)),
            daemon=True
        ).start()
        
        # Delete APK immediately (async)
        threading.Thread(
            target=lambda: _delete_apk_async(filepath),
            daemon=True
        ).start()
        
        # Build response
        firebase = result.get('firebase', {})
        
        response = {
            'status': 'success',
            'apk_name': filename,
            'package': result.get('package', 'unknown'),
            'version': result.get('version'),
            'firebase': {
                'project_id': firebase.get('project_id'),
                'api_key': firebase.get('api_key'),
                'app_id': firebase.get('app_id'),
                'db_url': firebase.get('db_url'),
                'storage_bucket': firebase.get('storage_bucket'),
                'sender_id': firebase.get('sender_id'),
                'config_version': firebase.get('config_version')
            },
            'uploaded_by': UPLOADED_BY,
            'timestamp': datetime.now().isoformat(),
            'processing_time_seconds': round(processing_time, 2),
            'quota': {
                'used': used,
                'remaining': remaining,
                'max': request.api_key_info['quota_max']
            }
        }
        
        # Remove null values
        response['firebase'] = {k: v for k, v in response['firebase'].items() if v is not None}
        
        return jsonify(response), 200
    
    except Exception as e:
        logger.error(f"API error: {str(e)}")
        try:
            os.remove(filepath)
        except:
            pass
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

@app.route('/status', methods=['GET'])
@api_key_required
def check_status():
    """Check quota and scan history"""
    
    used, remaining, can_process = db.check_quota(request.api_key)
    key_info = db.get_api_key_info(request.api_key)
    
    history = db.get_scan_history(request.api_key, limit=10)
    
    return jsonify({
        'status': 'ok',
        'api_key': request.api_key,
        'quota': {
            'used': used,
            'remaining': remaining,
            'max': key_info['quota_max']
        },
        'created_at': key_info['created_at'],
        'last_used': key_info['last_used'],
        'recent_scans': [
            {
                'apk_name': h['apk_name'],
                'package': h['package_name'],
                'timestamp': h['created_at'],
                'time_taken_seconds': round(h['processing_time'], 2)
            }
            for h in history
        ]
    }), 200

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🔐 ADMIN PANEL
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.route('/aryan', methods=['GET', 'POST'])
def admin_login():
    """Admin login with ID + Password"""
    
    if request.method == 'POST':
        user_id = request.form.get('user_id', '')
        password = request.form.get('password', '')
        
        if user_id == ADMIN_ID and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            session['admin_id'] = user_id
            return redirect(url_for('admin_dashboard'))
        else:
            return render_template('admin_login.html', error='Invalid credentials'), 401
    
    return render_template('admin_login.html')

@app.route('/aryan/dashboard')
@admin_login_required
def admin_dashboard():
    """Admin dashboard"""
    
    stats = db.get_stats()
    api_keys = db.list_all_api_keys()
    recent_logs = db.get_admin_log(limit=20)
    
    return render_template('admin_dashboard.html',
                          stats=stats,
                          api_keys=api_keys,
                          logs=recent_logs)

@app.route('/aryan/api/quota', methods=['POST'])
@admin_login_required
def admin_set_quota():
    """Admin: Set quota limit"""
    
    data = request.json
    api_key = data.get('api_key')
    new_limit = data.get('new_limit')
    
    db.set_quota_limit(api_key, new_limit)
    db.log_admin_action(session['admin_id'], 'SET_QUOTA', 
                       f"Key: {api_key}, Limit: {new_limit}")
    
    return jsonify({'status': 'ok'}), 200

@app.route('/aryan/api/ban', methods=['POST'])
@admin_login_required
def admin_ban_key():
    """Admin: Ban API key"""
    
    data = request.json
    api_key = data.get('api_key')
    
    db.ban_api_key(api_key)
    db.log_admin_action(session['admin_id'], 'BAN_KEY', f"Key: {api_key}")
    
    return jsonify({'status': 'ok'}), 200

@app.route('/aryan/api/unban', methods=['POST'])
@admin_login_required
def admin_unban_key():
    """Admin: Unban API key"""
    
    data = request.json
    api_key = data.get('api_key')
    
    db.unban_api_key(api_key)
    db.log_admin_action(session['admin_id'], 'UNBAN_KEY', f"Key: {api_key}")
    
    return jsonify({'status': 'ok'}), 200

@app.route('/aryan/logout')
def admin_logout():
    session.clear()
    return redirect(url_for('admin_login'))

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🛠️ HELPERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _delete_apk_async(filepath, delay=APK_CLEANUP_DELAY):
    """Delete APK after processing"""
    import time
    time.sleep(delay)
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            logger.info(f"Deleted: {filepath}")
    except Exception as e:
        logger.error(f"Delete error: {str(e)}")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🚀 RUN
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == '__main__':
    # Render uses PORT env variable
    port = int(os.getenv('PORT', 5000))
    
    print(f"""
╔══════════════════════════════════════════╗
║     🔥 ARYAN FIREBASE API RUNNING 🔥    ║
║     Render-Optimized | Async-Ready      ║
╚══════════════════════════════════════════╝

📍 API:    http://0.0.0.0:{port}
🔐 Admin:  http://localhost:{port}/aryan
💾 Storage: /tmp/aryan_uploads (ephemeral)
📊 DB:     {DATABASE_URL}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")
    
    app.run(
        host=API_HOST,
        port=port,
        debug=DEBUG,
        threaded=True
    )
